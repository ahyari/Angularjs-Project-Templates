﻿(function (module) {
    'use strict';

    var $fileinputname$ = function (depService) {
        this.getData = getData;

        function getData() { }
    };

    $fileinputname$.$inject = ['depService'];

    module.service('$fileinputname$', $fileinputname$);

}(angular.module('app1')));