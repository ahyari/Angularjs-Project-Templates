﻿(function (module) {
    'use strict';

    var $fileinputname$ = function (depService) {
        return {
            restrict: 'A',
            template: '<div></div>',
            templateUrl: 'directive.html',
            replace: false,
            priority: 0,
            transclude: false,
            scope: false,
            terminal: false,
            require: false, // 'siblingDirectiveName', // or // ['^parentDirectiveName', '?optionalDirectiveName', '?^optionalParent'],
            controller: function ($scope, $element, $attrs, $transclude, otherInjectables) {

            },
            controllerAs: '',
            bindToController: false,           
            compile: function compile(tElement, tAttrs, transclude) {
                return {
                    pre: function preLink(scope, iElement, iAttrs, controller) {  },
                    post: function postLink(scope, iElement, iAttrs, controller) {  }
                }
            },
            link: function postLink(scope, iElement, iAttrs) {

            }
        };
    };
    
    $fileinputname$.$inject = ['depService'];
    
    module.directive('$fileinputname$', $fileinputname$);

}(angular.module('app1')));