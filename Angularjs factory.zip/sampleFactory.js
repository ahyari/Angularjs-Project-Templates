﻿(function (module) {
    'use strict';
    
    var $fileinputname$ = function (depService) {

        function callToServer() {

        };

        return {
            callToServer: callToServer,
        };

    };

    $fileinputname$.$inject = ['depService'];

    module.factory('$fileinputname$', $fileinputname$);

}(angular.module('app1')));