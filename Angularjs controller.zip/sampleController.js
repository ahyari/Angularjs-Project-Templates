﻿(function (module) {
    'use strict';    

    function $fileinputname$(depService) {
        var vm = this;
              
    };

    $fileinputname$.$inject = ['depService'];

    module.controller('$fileinputname$', $fileinputname$);

}(angular.module('app1')));
