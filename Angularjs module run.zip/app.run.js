﻿(function (module) {
    'use strict';

    var run = function (depService) {

    };

    run.$inject = ['depService'];

    module.run(run);

}(angular.module('app1')));
