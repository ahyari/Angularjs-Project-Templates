﻿(function (module) {
    'use strict';

    var config = function (depProvider) {
     
    };

    config.$inject = ['depProvider'];

    module.config(config);

}(angular.module('app1')));
