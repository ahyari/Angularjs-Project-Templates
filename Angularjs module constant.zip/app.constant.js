﻿(function (module) {
    'use strict';

    module.constant('name', 'value');

}(angular.module('app1')));
