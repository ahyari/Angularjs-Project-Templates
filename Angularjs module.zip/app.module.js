﻿(function () {
    'use strict';

    angular.module('$fileinputname$', [
         // Angular modules
        'ngAnimate',
        'ngRoute'

        // Custom modules

        // 3rd Party Modules
    ]);
}());
