﻿(function (module) {
    'use strict';

    var $fileinputname$ = function (depService) {
        
        function filter1Filter(input,argument1,.....) {
            return input+ argument1;
        };

        return filter1Filter;
    };

    $fileinputname$.$inject = ['depService'];

    module.filter('$fileinputname$', $fileinputname$);

}(angular.module('app1')));