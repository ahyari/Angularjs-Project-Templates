﻿(function (module) {
    'use strict';

    var $fileinputname$ =  function (depService) {
        var configValue = false;

        this.setConfigValue = function (value) {
            configValue = value;
        };

        this.$get = provider1Factory;

        provider1Factory.$inject = ['$http'];
        function provider1Factory($http) {
            var service = {
                getData: getData
            };

            return service;


            function getData() {
                return configValue;
            }
        }
    };

    $fileinputname$.$inject = ['depService'];

    module.provider('$fileinputname$', $fileinputname$);

}(angular.module('app1')));