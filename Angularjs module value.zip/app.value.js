﻿(function (module) {
    'use strict';

    module.value('name', 'value');

}(angular.module('app1')));
