﻿(function (module) {
    'use strict';

    module.config(function (injectables) { // instance-injector
        // This is an example of a run block.
        // You can have as many of these as you want.
        // You can only inject instances (not Providers)
        // into run blocks
    });

})(angular.module('app1'));
