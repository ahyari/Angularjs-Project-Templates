﻿(function () {
    'use strict';

    angular.module('app1', [
        // Angular modules
        'ngAnimate',
        'ngRoute',

        // Custom modules
        'shared'
        // 3rd Party Modules
        
    ]);
})();
