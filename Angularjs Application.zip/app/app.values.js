﻿(function (module) {
    'use strict';

   // module.value('', '');

})(angular.module('app1'));
