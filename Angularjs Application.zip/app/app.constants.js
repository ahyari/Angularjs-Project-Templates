﻿(function (module) {
    'use strict';

    //module.constant('', '');

})(angular.module('app1'));
