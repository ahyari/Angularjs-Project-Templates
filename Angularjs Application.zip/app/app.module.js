﻿(function () {
    'use strict';

    angular.module('app1', [
        // Angular modules
        'ngAnimate',
        'ngRoute'

        // Custom modules

        // 3rd Party Modules
        
    ]);
})();
